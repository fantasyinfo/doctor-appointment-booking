<?php 
// site name
define('SITENAME', 'Appointment Booking');
// database hosts
define('DBHOST', 'localhost');
// database user
define('DBUSER', 'root');
// database hosts
define('DBPASSWORD', 'mysql');
// database hosts
define('DBNAME', 'doctor_booking_db');



?>