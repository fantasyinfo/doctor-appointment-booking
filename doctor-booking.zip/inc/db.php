<?php 

include('constant.php');

// connection to database
$conn = mysqli_connect(DBHOST,DBUSER,DBPASSWORD,DBNAME) or die("connection not established due to error.");





?>